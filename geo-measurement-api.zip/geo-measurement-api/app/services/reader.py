"""Reading Shapefile (.zip) and KML uploads into plain feature records."""
import json
import zipfile
from dataclasses import dataclass
from pathlib import Path

import geopandas as gpd
import pyogrio
from pyproj import CRS
from shapely.geometry.base import BaseGeometry

from app.config import settings
from app.services.crs import crs_label

SHP_SIDECARS = {".shp", ".shx", ".dbf", ".prj", ".cpg"}


class ProcessingError(Exception):
    """The file was accepted but could not be turned into features."""


@dataclass
class RawFeature:
    index: int
    layer: str
    crs: CRS
    geom: BaseGeometry | None
    geometry_geojson: dict | None
    properties: dict


def safe_extract_shapefile_zip(zip_path: Path, dest: Path) -> list[Path]:
    """Extract only shapefile components, flattened, guarding against zip-slip/zip-bombs."""
    try:
        zf = zipfile.ZipFile(zip_path)
    except zipfile.BadZipFile as exc:
        raise ProcessingError("Not a valid zip archive") from exc
    with zf:
        infos = [i for i in zf.infolist() if not i.is_dir()]
        if sum(i.file_size for i in infos) > settings.max_uncompressed_bytes:
            raise ProcessingError("Archive is too large when uncompressed")
        for info in infos:
            name = Path(info.filename).name  # flatten -> neutralises ../ and absolute paths
            if name.startswith(".") or "__MACOSX" in info.filename:
                continue
            if Path(name).suffix.lower() in SHP_SIDECARS:
                (dest / name).write_bytes(zf.read(info))
    shps = sorted(dest.glob("*.shp")) + sorted(dest.glob("*.SHP"))
    if not shps:
        raise ProcessingError("Zip does not contain a .shp file")
    return shps


def _read_layer(path: Path, layer: str | None, label: str) -> gpd.GeoDataFrame:
    try:
        gdf = gpd.read_file(path, layer=layer, engine="pyogrio") if layer else \
            gpd.read_file(path, engine="pyogrio")
    except Exception as exc:
        raise ProcessingError(f"Could not read '{label}': {exc}") from exc
    return gdf


def _records(gdf: gpd.GeoDataFrame, layer: str, start: int) -> list[RawFeature]:
    if gdf.crs is None:
        raise ProcessingError(
            f"Layer '{layer}' has no CRS (shapefile is missing its .prj); cannot measure safely")
    # to_json makes properties/geometry JSON-safe (NaN -> null, timestamps -> ISO strings)
    fc = json.loads(gdf.to_json(drop_id=True, na="null"))
    out = []
    for i, (geom, f) in enumerate(zip(gdf.geometry, fc["features"])):
        out.append(RawFeature(start + i, layer, gdf.crs, geom, f.get("geometry"),
                              f.get("properties") or {}))
    return out


def read_features(path: Path, file_type: str, workdir: Path) -> tuple[str, list[RawFeature]]:
    """Returns (file-level CRS label, features)."""
    features: list[RawFeature] = []

    if file_type == "kml":
        try:
            layers = [str(n) for n, _ in pyogrio.list_layers(path)]
        except Exception as exc:
            raise ProcessingError(f"Could not read KML: {exc}") from exc
        for name in layers:
            gdf = _read_layer(path, name, name)
            features += _records(gdf, name, len(features))
            if len(features) > settings.max_features:
                raise ProcessingError(f"Too many features (limit {settings.max_features})")
    else:
        for shp in safe_extract_shapefile_zip(path, workdir):
            gdf = _read_layer(shp, None, shp.name)
            features += _records(gdf, shp.stem, len(features))
            if len(features) > settings.max_features:
                raise ProcessingError(f"Too many features (limit {settings.max_features})")

    if not features:
        raise ProcessingError("File contains no features")

    labels = {crs_label(f.crs) for f in features}
    return (labels.pop() if len(labels) == 1 else "MIXED"), features
