"""Projected-CRS selection and cached coordinate transformers.

Strategy: measure in the UTM zone that contains the feature's centroid
(UPS near the poles). UTM is conformal and accurate to ~0.04% inside its zone,
which is more than adequate for parcel/survey-scale features.
"""
from functools import lru_cache

import numpy as np
import shapely
from pyproj import CRS, Transformer
from shapely.geometry.base import BaseGeometry

WGS84 = CRS.from_epsg(4326)


@lru_cache(maxsize=256)
def _transformer(src: str, dst: str) -> Transformer:
    # always_xy=True -> (lon, lat) / (x, y) order regardless of the CRS axis definition
    return Transformer.from_crs(CRS.from_user_input(src), CRS.from_user_input(dst), always_xy=True)


def reproject(geom: BaseGeometry, src: CRS | str, dst: CRS | str) -> BaseGeometry:
    src_s, dst_s = CRS.from_user_input(src).to_wkt(), CRS.from_user_input(dst).to_wkt()
    if src_s == dst_s:
        return geom
    t = _transformer(src_s, dst_s)

    def _apply(coords: np.ndarray) -> np.ndarray:
        x, y = t.transform(coords[:, 0], coords[:, 1])
        return np.column_stack([x, y])

    return shapely.transform(geom, _apply)


def utm_epsg_for(lon: float, lat: float) -> int:
    """EPSG code of the UTM zone (or UPS polar zone) containing lon/lat."""
    if lat >= 84.0:
        return 32661  # WGS 84 / UPS North
    if lat < -80.0:
        return 32761  # WGS 84 / UPS South
    zone = int((lon + 180.0) // 6.0) % 60 + 1
    return (32600 if lat >= 0 else 32700) + zone


def projected_crs_for(geom_wgs84: BaseGeometry) -> CRS:
    if geom_wgs84.is_empty:
        raise ValueError("cannot choose a projected CRS for an empty geometry")
    c = geom_wgs84.representative_point()  # always lies on/in the geometry
    return CRS.from_epsg(utm_epsg_for(c.x, c.y))


def crs_label(crs: CRS) -> str:
    epsg = crs.to_epsg()
    return f"EPSG:{epsg}" if epsg else (crs.name or "UNKNOWN")
