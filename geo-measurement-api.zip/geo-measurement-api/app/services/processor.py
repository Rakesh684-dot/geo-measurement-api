"""Orchestrates: read -> measure -> persist."""
import tempfile
from pathlib import Path

from sqlalchemy.orm import Session

from app.models import Feature, FileStatus, GeoFile
from app.services.crs import crs_label
from app.services.measure import measure
from app.services.reader import ProcessingError, read_features


def process_upload(db: Session, upload_path: Path, filename: str, file_type: str) -> GeoFile:
    record = GeoFile(filename=filename, file_type=file_type, status=FileStatus.PROCESSING.value)
    db.add(record)
    db.commit()

    try:
        with tempfile.TemporaryDirectory() as tmp:
            file_crs, raws = read_features(upload_path, file_type, Path(tmp))

        rows = []
        for r in raws:
            m = measure(r.geom, r.crs)
            rows.append(Feature(
                file_id=record.id, index=r.index, layer=r.layer,
                geometry_type=r.geom.geom_type if r.geom is not None else None,
                geometry=r.geometry_geojson, properties=r.properties, crs=crs_label(r.crs),
                measurement_status=m.status, measurement_note=m.note,
                area_sq_m=m.area_sq_m, length_m=m.length_m, projected_crs=m.projected_crs))
        db.add_all(rows)
        record.crs = file_crs
        record.feature_count = len(rows)
        record.status = FileStatus.COMPLETED.value
    except ProcessingError as exc:
        db.rollback()
        record = db.get(GeoFile, record.id)
        record.status, record.error = FileStatus.FAILED.value, str(exc)
    except Exception as exc:  # unexpected: record it, don't crash the request
        db.rollback()
        record = db.get(GeoFile, record.id)
        record.status, record.error = FileStatus.FAILED.value, f"Unexpected error: {exc}"[:500]
    db.commit()
    return record
