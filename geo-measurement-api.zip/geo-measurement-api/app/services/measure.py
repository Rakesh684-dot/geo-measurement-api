"""Per-feature measurement logic."""
import math
from dataclasses import dataclass

import shapely
from pyproj import CRS
from shapely.geometry.base import BaseGeometry

from app.services.crs import WGS84, crs_label, projected_crs_for, reproject

MEASURED = "MEASURED"
NOT_REQUIRED = "NOT_REQUIRED"
UNSUPPORTED = "UNSUPPORTED"

_POLYGONAL = {"Polygon", "MultiPolygon"}
_LINEAR = {"LineString", "MultiLineString"}
_POINTS = {"Point", "MultiPoint"}


@dataclass
class Measurement:
    status: str
    area_sq_m: float | None = None
    length_m: float | None = None
    projected_crs: str | None = None
    note: str | None = None


def measure(geom: BaseGeometry | None, src_crs: CRS) -> Measurement:
    """Measure one geometry. Never raises for bad/unsupported input."""
    if geom is None or geom.is_empty:
        return Measurement(UNSUPPORTED, note="Missing or empty geometry")

    gtype = geom.geom_type
    if gtype in _POINTS:
        return Measurement(NOT_REQUIRED, note="No measurement defined for points")
    if gtype not in _POLYGONAL | _LINEAR:
        return Measurement(UNSUPPORTED, note=f"Measurement not supported for {gtype}")

    try:
        geom = shapely.force_2d(geom)
        note = None
        if not geom.is_valid:
            note = "Invalid geometry (e.g. self-intersection); result may be unreliable"

        geom_wgs84 = reproject(geom, src_crs, WGS84)
        minx, miny, maxx, maxy = geom_wgs84.bounds
        if not all(math.isfinite(v) for v in (minx, miny, maxx, maxy)) \
                or miny < -90 or maxy > 90 or minx < -360 or maxx > 360:
            return Measurement(UNSUPPORTED, note="Coordinates outside the valid range for the CRS")
        proj = projected_crs_for(geom_wgs84)
        projected = reproject(geom_wgs84, WGS84, proj)

        if gtype in _POLYGONAL:
            return Measurement(MEASURED, area_sq_m=round(projected.area, 4),
                               projected_crs=crs_label(proj), note=note)
        return Measurement(MEASURED, length_m=round(projected.length, 4),
                           projected_crs=crs_label(proj), note=note)
    except Exception as exc:  # e.g. coordinates outside the CRS valid range
        return Measurement(UNSUPPORTED, note=f"Measurement failed: {exc}"[:250])
