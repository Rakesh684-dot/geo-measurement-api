import shutil
import tempfile
from pathlib import Path

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile
from fastapi.responses import JSONResponse
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.config import settings
from app.db import get_db
from app.models import Feature, FileStatus, GeoFile
from app.schemas import (FeatureOut, FeaturesResponse, FileOut, MeasurementOut,
                         MeasurementsResponse, MeasurementSummary)
from app.services.processor import process_upload

router = APIRouter(prefix="/api/files", tags=["files"])

EXT_TO_TYPE = {".kml": "kml", ".zip": "shapefile"}
CHUNK = 1024 * 1024


def _get_file(db: Session, file_id: str) -> GeoFile:
    f = db.get(GeoFile, file_id)
    if f is None:
        raise HTTPException(404, "File not found")
    return f


def _require_completed(f: GeoFile) -> None:
    if f.status != FileStatus.COMPLETED.value:
        raise HTTPException(409, f"File status is {f.status}" + (f": {f.error}" if f.error else ""))


@router.post("/", response_model=FileOut, status_code=201)
def upload_file(file: UploadFile = File(...), db: Session = Depends(get_db)):
    """Upload a .kml or a .zip containing a Shapefile; it is processed synchronously."""
    name = Path(file.filename or "").name
    file_type = EXT_TO_TYPE.get(Path(name).suffix.lower())
    if file_type is None:
        raise HTTPException(415, "Unsupported file type. Upload a .kml or a .zip containing a Shapefile.")

    with tempfile.TemporaryDirectory() as tmp:
        dest = Path(tmp) / name  # keep original name so KML layer names are meaningful
        size = 0
        with dest.open("wb") as out:
            while chunk := file.file.read(CHUNK):
                size += len(chunk)
                if size > settings.max_upload_bytes:
                    raise HTTPException(413, f"File exceeds {settings.max_upload_bytes // (1024 * 1024)} MB limit")
                out.write(chunk)
        if size == 0:
            raise HTTPException(400, "Uploaded file is empty")
        record = process_upload(db, dest, name, file_type)

    if record.status == FileStatus.FAILED.value:
        body = FileOut.model_validate(record).model_dump(mode="json")
        return JSONResponse(status_code=422, content={"detail": record.error, "file": body})
    return record


@router.get("/", response_model=list[FileOut])
def list_files(limit: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0),
               db: Session = Depends(get_db)):
    q = select(GeoFile).order_by(GeoFile.created_at.desc()).limit(limit).offset(offset)
    return db.scalars(q).all()


@router.get("/{file_id}/", response_model=FileOut)
def get_file(file_id: str, db: Session = Depends(get_db)):
    return _get_file(db, file_id)


@router.get("/{file_id}/features/", response_model=FeaturesResponse)
def get_features(file_id: str, limit: int = Query(100, ge=1, le=1000), offset: int = Query(0, ge=0),
                 db: Session = Depends(get_db)):
    """Extracted features: index, geometry type, GeoJSON geometry (source CRS), CRS, properties."""
    f = _get_file(db, file_id)
    _require_completed(f)
    rows = db.scalars(select(Feature).where(Feature.file_id == file_id)
                      .order_by(Feature.index).limit(limit).offset(offset)).all()
    return FeaturesResponse(file_id=file_id, total=f.feature_count, limit=limit, offset=offset,
                            features=[FeatureOut.model_validate(r) for r in rows])


@router.get("/{file_id}/measurements/", response_model=MeasurementsResponse)
def get_measurements(file_id: str, limit: int = Query(100, ge=1, le=1000),
                     offset: int = Query(0, ge=0), db: Session = Depends(get_db)):
    f = _get_file(db, file_id)
    _require_completed(f)

    rows = db.scalars(select(Feature).where(Feature.file_id == file_id)
                      .order_by(Feature.index).limit(limit).offset(offset)).all()

    agg = db.execute(
        select(func.coalesce(func.sum(Feature.area_sq_m), 0.0), func.coalesce(func.sum(Feature.length_m), 0.0),
               Feature.measurement_status, func.count())
        .where(Feature.file_id == file_id).group_by(Feature.measurement_status)).all()
    counts = {status: n for _, _, status, n in agg}
    summary = MeasurementSummary(
        total_area_sq_m=round(sum(a for a, _, _, _ in agg), 4),
        total_length_m=round(sum(l for _, l, _, _ in agg), 4),
        measured=counts.get("MEASURED", 0), not_required=counts.get("NOT_REQUIRED", 0),
        unsupported=counts.get("UNSUPPORTED", 0))

    items = [MeasurementOut(index=r.index, layer=r.layer, geometry_type=r.geometry_type, crs=r.crs,
                            projected_crs=r.projected_crs, status=r.measurement_status,
                            area_sq_m=r.area_sq_m, length_m=r.length_m, note=r.measurement_note)
             for r in rows]
    return MeasurementsResponse(file_id=file_id, total=f.feature_count, limit=limit, offset=offset,
                                summary=summary, measurements=items)


@router.delete("/{file_id}/", status_code=204)
def delete_file(file_id: str, db: Session = Depends(get_db)):
    db.delete(_get_file(db, file_id))
    db.commit()
